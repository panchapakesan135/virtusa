package net.javaguides.springboot.springboothelloworldtutorial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootHelloworldTutorialApplicationTests {

	@Test
	void contextLoads() {
	}

}
